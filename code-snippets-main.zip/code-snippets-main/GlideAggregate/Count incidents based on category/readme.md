Go to background and execute the script then you will get the total count of incidents based on category.

It will easily help to segregate the data based on categories/priority/ etc anything.
