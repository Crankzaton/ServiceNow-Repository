A code snippet to show how to obtain the list of accepted values for a given choice field.
It also uses `j2js()` to convert the output array from Java to Javascript.