# EfficientGlideRecord
See related article for full usage instructions and API documentation:  
https://go.snc.guru/egr