This code snippet will help you to generate tasks automatically for each row of MRVS present on RITM. This can be achieved by using a Before BR on RITM.
Specifications for Business rule will be:
1. When = Before
2. Insert = true
3. Advanced = true
4. Then write the script provided in script.js into the script section of BR.
