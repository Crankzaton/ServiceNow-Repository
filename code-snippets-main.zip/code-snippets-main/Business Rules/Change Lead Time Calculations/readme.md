Before business rule runs on insert/update - you can set the conditions as you require. Script in change_lead_time_calculations.js

System property name:change.leadtime.values | type:string | value -> { "High": 5, "Moderate" : 3, "Low" : 1 } 
