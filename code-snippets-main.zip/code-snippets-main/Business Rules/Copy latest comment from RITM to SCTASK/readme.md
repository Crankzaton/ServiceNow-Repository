This simple snap code helps to copy latest comment of RITM to SCTASK.
