This business rule script copies the additional comments from RITM to all associated SCTASKs when additional comments are changed on the RITM.
