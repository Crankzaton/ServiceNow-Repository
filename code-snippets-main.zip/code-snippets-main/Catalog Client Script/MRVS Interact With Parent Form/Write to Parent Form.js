Use the g_service_catalog.parent object to interact with the parent form from within a MVRS script

//Retrieve a variable value from the parent form
g_service_catalog.parent.getValue('variable_name');

//Set a variable value on the parent form
g_service_catalog.parent.setValue('variable_name');
