OnSUbmit Catalog Client script is created to Combine all variable values required and display in Description field.
Steps:
1. Navigate to your instance open catalog client script table [catalog_script_client]
2. Create new catalog client script -> click new
3. Provide following values:
      - Name: Any relevant to your script
      - Applies to: A catalog Item
      - UI Type: All
      - Isolated script: checked
      - Application: Application scope applies to
      - Type: onSubmit
      - Catalog item: select your catalog item
 4. create the script as per script.js file.  
