function onLoad()
{
  
   g_form.setVariablesReadOnly(true); //if you want to make all variables read-only
  
   g_form.setVariablesReadOnly(false); //if you want to make all variables editable
  
}
