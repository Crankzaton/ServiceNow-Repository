# Enable Mandatory Attachments Count wtih 'n' numbers on Service Catalog item
**Problem:** Check if exact 'n' number of attachments are added or not when user submit a request through service catalog from Portal/Platform UI.

**For example:** We need to ensure there are exact 3 attachments added before submission

**Note:** Ensure Isolate Script field is set to False for this Catalog Client Script to ensure DOM manipulation works

* [Click here for script](onSubmitClientScript.js)
