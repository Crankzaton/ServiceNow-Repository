This script is OnChange, and will automatically round the selected field to [x] value.
The script can either be applied to a Catalog Item, or a specific Variable in a Var Set.

For example, if prompting a user for a cost, and said cost should only be in multiples of $5.

Any instance of `[VAR NAME]` in these files should be replaced with the name of the variable that the script is being applied to.

More information and a full write-up available on [Community](https://community.servicenow.com/community?id=community_article&sys_id=75ab01271bac5d10c17111751a4bcb40).