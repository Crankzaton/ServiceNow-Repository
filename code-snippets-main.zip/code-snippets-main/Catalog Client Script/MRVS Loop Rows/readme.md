Use this to loop through a Multi Row Variable Set and create an array of objects with the variables in it.
