# Prevent duplicate records to be selected in Multi row variable set

We have many ways to do this but this is bit unique compare to what you find in community, you can do it in one single script within the Variable set. 
Of course ServiceNow introduce a new feature in Quebec and have Unique checkbox field introuduced but to have a custom info message you need to go with the custom script.

  [ServiceNow Docs to disallow duplicate values](https://docs.servicenow.com/bundle/quebec-servicenow-platform/page/product/service-catalog-management/task/t_CreateAVariableForACatalogItem.html)
  
  [Click here for the script](script.js)
