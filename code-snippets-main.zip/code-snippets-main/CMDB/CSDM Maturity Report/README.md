# CSDM Maturity Report

This code snippet generates a report that helps with assessing an organization's Common Services Data Model (CSDM) maturity

It counts the number of records in the tables that are part of the CSDM by category
