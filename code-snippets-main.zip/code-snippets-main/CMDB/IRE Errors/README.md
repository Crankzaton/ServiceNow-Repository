# IRE Errors

This code snippet displays a count of IRE errors grouped by category 
This background script will help you undertand the most common source of IRE errors
You will need to adjust the record limit in line 30, or change the query time frame in line 27

