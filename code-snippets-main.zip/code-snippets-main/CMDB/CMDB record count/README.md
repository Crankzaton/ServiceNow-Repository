# CMDB Record count

Simple code snippet to count the number of records in each CMDB table
