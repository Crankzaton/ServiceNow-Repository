This script is used to combine 2 internal tables:sc_req_item and sc_item_produced_record from a Report Table Definition => Script tab. 
We can create a report on the created remote table (Pie chart). 
