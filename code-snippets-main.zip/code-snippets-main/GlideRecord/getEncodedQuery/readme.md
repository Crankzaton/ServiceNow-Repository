1.In any GlideRecord query retrieve query using getEncodedQuery()

2.Apply this encoded query to create/update records (you can apply this query to other tables if query is appropriate).

![image](https://user-images.githubusercontent.com/42912180/195796801-4758afd0-4c35-4405-9836-560c6041dd4a.png)




Before Running the script :
![image](https://user-images.githubusercontent.com/42912180/195796529-cad998a9-c97e-40d7-b2b0-7bb48aaecf9a.png)


After Running the script:
![image](https://user-images.githubusercontent.com/42912180/195796411-dcb20d99-2bd7-4ef6-88bc-846f46006122.png)
