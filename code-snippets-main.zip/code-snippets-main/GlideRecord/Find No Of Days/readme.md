This code will let you find the date difference between the provided dates: Helps in calculating No of days, payment processing , etc.
