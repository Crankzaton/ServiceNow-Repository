This sripts is used to find Duplicate Records in the 'asset' table you can change table as per your wish.
Duplicates are counted on 'asset_tag'.
If count is greater than 2 than we add it to array.
