Logic to check if new dates are falling between already created record's dates.
