Using GlideRecordSecure to query data with built in access checks is as simple as that! With this class and associated API, you can have confidence that your data is, well, secure!

When utilizing this class and associated API within scripts, the same rules as GlideRecord apply. On the “server side” (like in a Business Rule), the GlideRecordSecure API can only be run from scripts within global or scoped applications. On the “client side” (like in a Client Script), the GlideRecord API can only be run from scripts within global applications.
