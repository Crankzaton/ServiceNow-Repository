(function execute(inputs, outputs) {
    outputs.value = gs.getProperty(inputs.property);
})(inputs, outputs);