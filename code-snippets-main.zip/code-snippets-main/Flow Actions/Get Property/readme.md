Flow Action to return the value of a sys_properties

Action requires:
- One string input for sys_properties name
- Script Step (provided in getPropertyFlowAction.js)
- One string output for returned value