Useful for tasks like triggering notifications or to trigger asynchronous script actions from a flow. 

This flow action triggers the passed in event with optional parameters. Will work for most scenarios as the event record is passed in as a Document ID input.

Inputs:

event_name		- Reference.Event Record - Mandatory

event_record	- Document ID            - Mandatory

parm1					- String 

parm2					- String

