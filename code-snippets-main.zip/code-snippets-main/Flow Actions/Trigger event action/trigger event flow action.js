(function execute(inputs, outputs) {
  
  gs.eventQueue(inputs.event_name, inputs.event_record, inputs.parm1, inputs.parm2);

})(inputs, outputs);
