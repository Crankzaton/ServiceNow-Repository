This code help to set the RITM description as the summary of catalog item variables.
we can reuse the code on catalog workflows in runscript activity and flow designers
