## Action Script to check mid server availability

### Use this script in a new flow action to check if a mid server is up/available or not. This can be used to for orchestration projects or similar. 
### Note: The script returns availability as true/false back as the action output to the flow.
