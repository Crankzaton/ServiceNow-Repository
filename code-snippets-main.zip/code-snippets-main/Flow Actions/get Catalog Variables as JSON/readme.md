Get catalog variables from a given RITM
