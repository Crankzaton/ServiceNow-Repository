# Group Approval Check

### This is an email notification advanced condition script for approval requests that will check if an approval has already been granted prior to sending out a request.

This script can be applied to any approval request notification on the sysapproval_approver table with no additional configuration necessary
