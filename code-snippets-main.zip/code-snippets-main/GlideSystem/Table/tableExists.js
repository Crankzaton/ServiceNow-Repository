var table = gs.tableExists('cmdb_ci'); //Name of the table
gs.info(table); //Will return a boolean

//Output Example:
//*** Script: true
