## Multiply records from filer breadcrumbs

Using this script you can multiply records (such as Story, Incident, SCTASK, ...), while assigning them to a different user. 
The script will also copy the attachments to the duplicate record.

I use this script to create sample stories / incidents for our new joiners that they can practice on in a non productive instance.
