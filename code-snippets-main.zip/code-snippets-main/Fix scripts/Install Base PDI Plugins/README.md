# Install Base PDI Plugins

Fix Script to speed up installation of multiple plugins on a fresh PDI (even with demo data).

Options: (modify script as needed)
- plugins (array) includes names of the plugins to install
- include_demo_data (true/false) whether to install demo data or not (default=false)
