Script to Cancel the workflow context attached to a record
