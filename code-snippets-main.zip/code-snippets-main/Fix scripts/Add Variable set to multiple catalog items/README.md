### Add variable set to multiple catalog items through script

Use this fix script to associate new variable set to few/all catalog items through script.
Use sys_ids of all catalog items and Variable set in the script.
