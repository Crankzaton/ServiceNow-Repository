# Set a unique banner to your non-production instance to help users realise where they are :)
 ## Can be used as clean-up script on a clone profile, or run as fix script, background script etc. manually on the target instance after cloning.


 ### Prerequisites:
 * 1) You need to have the target instance's banner image attached to a record on the source system, e.g. have a knowledge article in production with the banner attached to it.
 * 2) Make sure the table above mentioned table and record and included in your clone!
 * 3) Set the source table name and the source record's sys_id as values for srcTbl and srcRec variables in the below section!
