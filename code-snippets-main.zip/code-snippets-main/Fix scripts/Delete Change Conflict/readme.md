Use this script to delete change Conflicts and set conflict status as 'No Conflict' using fix script.
