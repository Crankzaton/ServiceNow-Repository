# Find duplicate records

Run the script to find duplicate records in a table. It is using GlideAggregate to find duplicate records. Replace the TABLE_TO_FIND_DUPLICATE_IN and FIELD_TO_GROUP_BY constants with your table and field and it will spit the records.
