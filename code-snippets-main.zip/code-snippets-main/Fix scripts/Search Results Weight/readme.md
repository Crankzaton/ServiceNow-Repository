# Find the weight of Search Results

The order in which search results are returned is based on the weight of the object against the searched value.  This script can be run as a background script to determine what results are returned for specific search results and what their weight is in the search.

This can be used to determine why one item might returned in front of another item.
