The script parses through a CSV attachment accessed from the instance and reads each data row by row and column by column. You could also specify the required separator and quote character to escape them.

Sample Usage:  

parseCSVFile("sys_id=76fc711f2f0b7050809e51172799b685");

