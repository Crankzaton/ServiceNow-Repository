For the workflows created using flow designer, the due date for sctasks is not populated automatically.
This code populates the due date of sctask automatically when RITMs are created through flow designers.
