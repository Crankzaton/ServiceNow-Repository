Use this script to know whether today is weekend or weekday.

It helps to restrict the schedule job/ any other activity during weekends.
