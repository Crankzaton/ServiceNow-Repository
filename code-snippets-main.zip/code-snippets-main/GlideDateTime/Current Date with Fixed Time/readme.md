This script helps to set fixed time to Present Date..
