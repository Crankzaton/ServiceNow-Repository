var gd = new GlideDate();
var gdt = new GlideDateTime();
gdt.setValue(gd + " 18:00:00");
gs.info(gdt);
