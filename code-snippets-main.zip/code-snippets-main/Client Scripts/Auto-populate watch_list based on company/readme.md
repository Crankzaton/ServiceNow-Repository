Table: Incident
Type: onChange
field: caller_id

Sometimes customers have a requirement to add users or distribution lists to all tickets that are raised for their company. This script allows to automatically add a list of users or external email addresses to the watch_list field.