# Client Script - Input is number only

A client script that validates that the input entry is number only

## Usage


- Create a new client script
- Set the type to OnChange. Update the field in the client script to <your field name>
- Select a field field that you want to be number
- Navigate to the form and set the field to a string
- There will be a validation error close to the field
