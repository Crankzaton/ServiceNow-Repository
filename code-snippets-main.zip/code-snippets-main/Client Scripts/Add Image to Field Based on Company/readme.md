# Add Image to Field Based on Company
From the User Profile get the Company associated to the User using a Display Business Rule and putting the value in the scratchpad. After that use the scratchpad value in the Client Script to check the company name and then associate the image accordingly. You would need to add all your images to the ServiceNow instance first with the correct names.
