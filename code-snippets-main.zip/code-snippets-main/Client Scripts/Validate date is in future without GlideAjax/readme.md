# Client Script - Date in future

A client script that validates that a specified date is in future without the need for a GlideAjax and Script Include

## Usage

- Create a new client script
- Set the type to OnChange
- Select a date field that you want to validate
- Navigate to the form and set the date field to the past
- There will be a validation error close to the field
