Using "onfocus" & "onblur" Show/Hide field messages while updating a field.

Example:On load Client script on the incident form

![image](https://user-images.githubusercontent.com/42912180/195825979-e69e5798-a241-4fe8-8f49-7f70f1f3ae6e.png)



**Quick video how it works:**


https://user-images.githubusercontent.com/42912180/195825799-aff13ca5-0b85-4660-98a3-ea1af8b61974.mp4

