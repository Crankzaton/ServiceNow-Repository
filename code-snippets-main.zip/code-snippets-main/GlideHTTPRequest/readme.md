GlideHTTPRequest API is used to work on Glide HTTP Request and Response.

API Documentation Link for "PARIS" release : https://developer.servicenow.com/dev.do#!/reference/api/paris/server_legacy/GlideHTTPRequestAPI

Please update the variable details in the script to check it.
