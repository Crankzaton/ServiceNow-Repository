This is to get the size of the DB from the SN instance using SNC.
