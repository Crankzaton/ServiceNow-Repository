# Logout Users
Used to log out all users within the platform.

## Usage
Run script in **logoutUser.js** in 'Scripts - Background'

* **Parameters:** 
    - **ignoreUser:** Username of a sys_user that is ignored (ex. 'admin')
