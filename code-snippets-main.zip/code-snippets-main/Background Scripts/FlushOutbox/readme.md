# Flush Outbox

Delete or Ignore all email sitting in the outbox. Useful when enabling email in sub-prd and not wanting to get spammed with unsent email
