This script helps to find out duplicate records in the table.

In this example I have shown how to find out records in incident table.
